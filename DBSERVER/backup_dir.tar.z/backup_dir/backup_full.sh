#!/bin/bash

# Verificar que se pasaron suficientes argumentos
if [ "$#" -lt 2 ]; 
then
	echo "Uso: $0 <directorios_origen> <directorio_destino>"
fi

#Ingresar los argumentos
DEST_DIR=$1
SRC_DIRS=("$@") 

#validar que el directorio de destino existe
if [ "$DEST_DIR" != "/backup_dir" ];
then
	echo "El directorio de destino no es el indicado"
fi


#Validar que los directorios de origen existen
for DIR in "${SRC_DIRS[@]}";
do
	if ! [ -d "$DIR" ];
	then 
		echo "ADvertencia el directorio origen $DIR no existe"
	fi
done

#Obtener fecha 
FECHA=$(date + '%Y%m%d')
HORA=(date + '%H')
DIA=(date + '%u')

#Respaldo de /etc y /var/logs diario a las 0hrs
if [ "$HOUR" -eq 0 ];
then 
	if [[ "${SRC_DIRS[@]}" =~ "/etc" ]];
	then 
		echo"Realizando el backup de /etc..."
		atr -czf "$BACKUP_DIR/etc_bkp_$DATEtar.gz" /etc
	fi

	if [[ "${SRC_DIRS[@]}" =~ "/var/logs" ]];
	then
		echo "Realizando backup de /var/logs..."
		tar -czf "$BACKUP_DIR/var_logs_bkp_$DATE.tar.gz" /var/logs
	fi
fi

#respaldo de /db_dir los lunes, miercoles y viernes a las 23hs
if [ "$HOUR" -eq 23];
then
	if [ "$DAY" -eq 1 ] || [ "$DAY" -eq 3 ]|| [ "$DAY" -eq 5]; 
	then
		if [[ "${SRC_DIRS[@]}" =~ "/db_dir" ]];
		then
			echo "Realizando backup de /db_dir..."
			tar -czf "$BACKUP_DIR/db_dir_bkp_$DATE.tar.gz" /db_dir
		fi
	fi
fi






